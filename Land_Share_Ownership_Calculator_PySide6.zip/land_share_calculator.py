
import sys, re, math
from pathlib import Path
import pandas as pd

from PySide6.QtCore import Qt
from PySide6.QtGui import QFont
from PySide6.QtWidgets import (
    QApplication, QMainWindow, QWidget, QVBoxLayout, QHBoxLayout, QGridLayout,
    QLabel, QPushButton, QDoubleSpinBox, QLineEdit, QTableWidget, QTableWidgetItem,
    QHeaderView, QMessageBox, QFileDialog, QGroupBox, QComboBox, QCheckBox,
    QSplitter, QPlainTextEdit, QFrame
)

APP_NAME = "Land Share & Ownership Calculator"
COLUMNS = ["Owners", "Fraction / Share", "Share", "Total Marla Share",
           "Killa", "Kanal", "Marla", "Sarshai", "Result"]

def parse_fraction(value):
    """Parse fractions such as 1/8, 3/16, decimals, or percentages."""
    if value is None:
        return None
    s = str(value).strip().replace(" ", "")
    if not s:
        return None
    try:
        if s.endswith("%"):
            return float(s[:-1]) / 100.0
        if "/" in s:
            parts = s.split("/")
            if len(parts) != 2:
                return None
            n, d = float(parts[0]), float(parts[1])
            if d == 0:
                return None
            return n / d
        return float(s)
    except (ValueError, TypeError):
        return None

def marla_to_kms(total_marla):
    """Convert decimal marla to Killa-Kanal-Marla-Sarshai."""
    if total_marla is None:
        return 0, 0, 0, 0
    # 1 Kanal = 20 Marla; 1 Killa = 8 Kanal = 160 Marla;
    # 1 Marla = 9 Sarshai.
    total_sarshai = int(round(float(total_marla) * 9))
    killa, rem = divmod(total_sarshai, 160 * 9)
    kanal, rem = divmod(rem, 20 * 9)
    marla, sarshai = divmod(rem, 9)
    return killa, kanal, marla, sarshai

def fmt_share(v):
    if v is None:
        return ""
    return f"{v:.6f}".rstrip("0").rstrip(".")

def fmt_num(v):
    return f"{v:.4f}".rstrip("0").rstrip(".")

class Calculator(QMainWindow):
    def __init__(self):
        super().__init__()
        self.setWindowTitle(APP_NAME)
        self.resize(1280, 820)
        self.build_ui()
        self.add_row("Owner 1", "1/2")
        self.add_row("Owner 2", "1/2")
        self.calculate()

    def build_ui(self):
        root = QWidget()
        self.setCentralWidget(root)
        main = QVBoxLayout(root)
        main.setContentsMargins(26, 22, 26, 22)
        main.setSpacing(14)

        header = QHBoxLayout()
        title = QLabel("📐 Land Share & Ownership")
        title.setObjectName("title")
        header.addWidget(title)
        header.addStretch()
        self.total_badge = QLabel("READY")
        self.total_badge.setObjectName("badge")
        header.addWidget(self.total_badge)
        main.addLayout(header)

        subtitle = QLabel("Calculate proportional land shares and convert them to Killa • Kanal • Marla • Sarshai.")
        subtitle.setObjectName("subtitle")
        main.addWidget(subtitle)

        splitter = QSplitter(Qt.Horizontal)
        main.addWidget(splitter, 1)

        left = QWidget()
        left_lay = QVBoxLayout(left)
        left_lay.setContentsMargins(0,0,8,0)

        area_box = QGroupBox("Total Land Area")
        area = QGridLayout(area_box)
        self.kanal = QDoubleSpinBox()
        self.kanal.setRange(0, 10000000)
        self.kanal.setDecimals(2)
        self.kanal.setValue(0)
        self.kanal.setSuffix(" kanal")
        self.kanal.valueChanged.connect(self.calculate)
        self.marla = QDoubleSpinBox()
        self.marla.setRange(0, 19.999999)
        self.marla.setDecimals(6)
        self.marla.setValue(0)
        self.marla.setSuffix(" marla")
        self.marla.valueChanged.connect(self.calculate)
        area.addWidget(QLabel("Kanal"), 0, 0)
        area.addWidget(self.kanal, 0, 1)
        area.addWidget(QLabel("Additional Marla"), 1, 0)
        area.addWidget(self.marla, 1, 1)
        self.area_label = QLabel("0 marla")
        self.area_label.setObjectName("areaLabel")
        area.addWidget(QLabel("Total"), 2, 0)
        area.addWidget(self.area_label, 2, 1)
        left_lay.addWidget(area_box)

        tools = QGroupBox("Ownership Tools")
        tl = QGridLayout(tools)
        self.preset = QComboBox()
        self.preset.addItems(["Custom", "Equal 2 owners", "Equal 3 owners", "Equal 4 owners", "Equal 5 owners", "Equal 8 owners"])
        self.preset.currentIndexChanged.connect(self.apply_preset)
        tl.addWidget(QLabel("Preset"), 0, 0)
        tl.addWidget(self.preset, 0, 1)
        add = QPushButton("＋ Add Owner")
        add.clicked.connect(lambda: self.add_row(f"Owner {self.table.rowCount()+1}", "0"))
        tl.addWidget(add, 1, 0)
        remove = QPushButton("− Remove Selected")
        remove.clicked.connect(self.remove_selected)
        tl.addWidget(remove, 1, 1)
        paste = QPushButton("Paste Table")
        paste.clicked.connect(self.paste_table)
        tl.addWidget(paste, 2, 0)
        clear = QPushButton("Clear")
        clear.clicked.connect(self.clear_table)
        tl.addWidget(clear, 2, 1)
        left_lay.addWidget(tools)

        import_box = QGroupBox("Data")
        il = QVBoxLayout(import_box)
        imp = QPushButton("📥 Import Excel / CSV")
        imp.clicked.connect(self.import_file)
        exp = QPushButton("📤 Export Results")
        exp.clicked.connect(self.export_file)
        il.addWidget(imp)
        il.addWidget(exp)
        left_lay.addWidget(import_box)

        help_box = QGroupBox("Input Formats")
        hl = QVBoxLayout(help_box)
        hl.addWidget(QLabel("Fraction: 1/8, 3/16, 5/32"))
        hl.addWidget(QLabel("Decimal: 0.125"))
        hl.addWidget(QLabel("Percentage: 12.5%"))
        hl.addWidget(QLabel("Shares should normally total 1.0 (100%)."))
        left_lay.addWidget(help_box)
        left_lay.addStretch()

        splitter.addWidget(left)

        right = QWidget()
        right_lay = QVBoxLayout(right)
        right_lay.setContentsMargins(8,0,0,0)

        summary = QHBoxLayout()
        self.summary_area = self.summary_card("TOTAL AREA", "0 marla")
        self.summary_alloc = self.summary_card("ALLOCATED", "0%")
        self.summary_unalloc = self.summary_card("REMAINING", "100%")
        summary.addWidget(self.summary_area)
        summary.addWidget(self.summary_alloc)
        summary.addWidget(self.summary_unalloc)
        right_lay.addLayout(summary)

        self.table = QTableWidget(0, 9)
        self.table.setHorizontalHeaderLabels(COLUMNS)
        self.table.setAlternatingRowColors(True)
        self.table.horizontalHeader().setSectionResizeMode(QHeaderView.Interactive)
        self.table.horizontalHeader().setStretchLastSection(True)
        self.table.setColumnWidth(0, 170)
        self.table.setColumnWidth(1, 120)
        self.table.itemChanged.connect(lambda _: self.calculate())
        right_lay.addWidget(self.table, 1)

        bottom = QHBoxLayout()
        self.validation = QLabel("")
        self.validation.setObjectName("validation")
        bottom.addWidget(self.validation)
        bottom.addStretch()
        calc = QPushButton("🧮 Calculate")
        calc.setObjectName("primary")
        calc.clicked.connect(self.calculate)
        bottom.addWidget(calc)
        right_lay.addLayout(bottom)

        splitter.addWidget(right)
        splitter.setSizes([310, 900])

        self.setStyleSheet("""
        QMainWindow, QWidget { background:#10151d; color:#e7edf5; }
        #title { font-size:29px; font-weight:700; }
        #subtitle { color:#9daabd; font-size:14px; }
        #badge { background:#173c2b; color:#82e5a5; padding:7px 13px; border-radius:12px; font-weight:700; }
        QGroupBox { border:1px solid #2b3647; border-radius:12px; margin-top:10px; padding:12px; font-weight:700; }
        QGroupBox::title { subcontrol-origin:margin; left:12px; padding:0 5px; color:#cbd5e1; }
        QDoubleSpinBox, QLineEdit, QComboBox, QPlainTextEdit {
            background:#171e28; border:1px solid #303c4f; border-radius:8px; padding:8px;
            color:#f2f5f8;
        }
        QPushButton { background:#1b2532; border:1px solid #344257; border-radius:8px; padding:9px 12px; }
        QPushButton:hover { background:#263346; }
        #primary { font-weight:700; padding:10px 20px; }
        #areaLabel { font-size:16px; font-weight:700; }
        #validation { font-weight:600; }
        QTableWidget { background:#151c26; border:1px solid #2b3647; border-radius:10px; gridline-color:#2b3647; }
        QHeaderView::section { background:#202a38; color:#dbe4ef; padding:9px; border:none; font-weight:700; }
        QTableWidget::item { padding:6px; }
        QTableWidget::item:selected { background:#314156; }
        """)

    def summary_card(self, name, value):
        frame = QFrame()
        frame.setStyleSheet("QFrame{background:#171e28;border:1px solid #2b3647;border-radius:12px;}")
        lay = QVBoxLayout(frame)
        a = QLabel(name)
        a.setStyleSheet("color:#91a0b4;font-size:11px;font-weight:700;")
        b = QLabel(value)
        b.setStyleSheet("font-size:19px;font-weight:700;")
        lay.addWidget(a)
        lay.addWidget(b)
        frame.value_label = b
        return frame

    def add_row(self, owner="", fraction=""):
        r = self.table.rowCount()
        self.table.insertRow(r)
        self.table.setItem(r, 0, QTableWidgetItem(owner))
        self.table.setItem(r, 1, QTableWidgetItem(fraction))
        for c in range(2, 9):
            item = QTableWidgetItem("")
            item.setFlags(item.flags() & ~Qt.ItemIsEditable)
            self.table.setItem(r, c, item)

    def remove_selected(self):
        rows = sorted({i.row() for i in self.table.selectedItems()}, reverse=True)
        for r in rows:
            self.table.removeRow(r)
        self.calculate()

    def clear_table(self):
        self.table.setRowCount(0)
        self.calculate()

    def apply_preset(self, index):
        if index == 0:
            return
        n = [0,2,3,4,5,8][index]
        self.table.setRowCount(0)
        share = f"1/{n}"
        for i in range(n):
            self.add_row(f"Owner {i+1}", share)
        self.calculate()

    def total_marla(self):
        return self.kanal.value() * 20 + self.marla.value()

    def calculate(self):
        total = self.total_marla()
        self.area_label.setText(f"{fmt_num(total)} marla")
        allocated = 0.0
        valid_rows = 0
        for r in range(self.table.rowCount()):
            owner = self.table.item(r,0).text().strip() if self.table.item(r,0) else ""
            raw = self.table.item(r,1).text().strip() if self.table.item(r,1) else ""
            share = parse_fraction(raw)
            if share is not None and share >= 0:
                allocated += share
                valid_rows += 1
                area = share * total
                k, kn, m, s = marla_to_kms(area)
                values = [fmt_share(share), fmt_num(area), str(k), str(kn), str(m), str(s),
                          f"{k}Ki-{kn}K-{m}M-{s}S"]
                for c, value in enumerate(values, start=2):
                    self.table.item(r,c).setText(value)
            else:
                for c in range(2,9):
                    self.table.item(r,c).setText("—")

        self.summary_area.value_label.setText(f"{fmt_num(total)} marla")
        self.summary_alloc.value_label.setText(f"{allocated*100:.2f}%")
        remaining = 1.0 - allocated
        self.summary_unalloc.value_label.setText(f"{remaining*100:.2f}%")

        if not self.table.rowCount():
            self.validation.setText("Add owners to begin.")
            self.total_badge.setText("READY")
            return

        if any(parse_fraction(self.table.item(r,1).text()) is None for r in range(self.table.rowCount())):
            self.validation.setText("⚠ Some share values are invalid.")
            self.total_badge.setText("CHECK INPUT")
        elif abs(allocated - 1.0) < 1e-9:
            self.validation.setText(f"✓ Ownership balanced — {valid_rows} valid owner rows")
            self.total_badge.setText("BALANCED")
        elif allocated < 1.0:
            self.validation.setText(f"ℹ {remaining*100:.2f}% of the land is unallocated.")
            self.total_badge.setText("PARTIAL")
        else:
            self.validation.setText(f"⚠ Ownership exceeds 100% by {(allocated-1)*100:.2f}%.")
            self.total_badge.setText("OVER-ALLOCATED")

    def paste_table(self):
        text = QApplication.clipboard().text().strip()
        if not text:
            QMessageBox.information(self, "Paste Table", "Copy a tab-separated table to the clipboard first.")
            return
        lines = [x for x in text.splitlines() if x.strip()]
        rows = [re.split(r"\t+", line) for line in lines]
        if not rows:
            return
        header = [x.strip().lower() for x in rows[0]]
        owner_i = next((i for i,x in enumerate(header) if x == "owners" or "owner" in x), 0)
        share_i = next((i for i,x in enumerate(header) if "fraction" in x or "share" in x), 1 if len(rows[0]) > 1 else None)
        if share_i is None:
            QMessageBox.warning(self, "Paste Table", "Could not find a Fraction / Share column.")
            return
        self.table.setRowCount(0)
        for row in rows[1:]:
            owner = row[owner_i].strip() if owner_i < len(row) else ""
            share = row[share_i].strip() if share_i < len(row) else ""
            self.add_row(owner, share)
        self.calculate()

    def import_file(self):
        path, _ = QFileDialog.getOpenFileName(self, "Import Ownership Data", "", "Excel (*.xlsx *.xls);;CSV (*.csv)")
        if not path:
            return
        try:
            df = pd.read_excel(path) if path.lower().endswith((".xlsx",".xls")) else pd.read_csv(path)
            cols = {str(c).strip().lower(): c for c in df.columns}
            owner_col = next((cols[k] for k in cols if k == "owners" or "owner" in k), None)
            share_col = next((cols[k] for k in cols if "fraction" in k or k == "share" or "share" in k), None)
            if not owner_col or not share_col:
                raise ValueError("File must contain Owners and Fraction / Share columns.")
            self.table.setRowCount(0)
            for _, row in df.iterrows():
                self.add_row(str(row[owner_col]), str(row[share_col]))
            self.calculate()
        except Exception as e:
            QMessageBox.critical(self, "Import failed", str(e))

    def export_file(self):
        self.calculate()
        path, selected = QFileDialog.getSaveFileName(
            self, "Export Results", "land_share_results.xlsx",
            "Excel Workbook (*.xlsx);;CSV (*.csv)"
        )
        if not path:
            return
        records = []
        for r in range(self.table.rowCount()):
            records.append({COLUMNS[c]: self.table.item(r,c).text() if self.table.item(r,c) else "" for c in range(9)})
        df = pd.DataFrame(records)
        try:
            if path.lower().endswith(".csv"):
                df.to_csv(path, index=False)
            else:
                with pd.ExcelWriter(path, engine="openpyxl") as writer:
                    df.to_excel(writer, index=False, sheet_name="Land Share Results")
                    ws = writer.book["Land Share Results"]
                    ws.freeze_panes = "A2"
                    for col in ws.columns:
                        max_len = max(len(str(cell.value or "")) for cell in col)
                        ws.column_dimensions[col[0].column_letter].width = min(max_len + 2, 35)
            QMessageBox.information(self, "Export complete", f"Saved results to:\n{path}")
        except Exception as e:
            QMessageBox.critical(self, "Export failed", str(e))

def main():
    app = QApplication(sys.argv)
    app.setApplicationName(APP_NAME)
    app.setFont(QFont("Segoe UI", 10))
    window = Calculator()
    window.show()
    return app.exec()

if __name__ == "__main__":
    sys.exit(main())
