# Land Share & Ownership Calculator

A standalone PySide6 desktop application for proportional land-share calculations using the Killa–Kanal–Marla–Sarshai representation.

## Features

- Total area entered as Kanal + additional Marla
- Fraction, decimal, and percentage share input
- Automatic Killa / Kanal / Marla / Sarshai conversion
- Ownership balance validation
- Remaining / over-allocated land calculation
- Equal-owner presets for 2, 3, 4, 5, and 8 owners
- Add/remove owner rows
- Paste tab-separated Excel-style tables
- Import `.xlsx`, `.xls`, or `.csv`
- Export calculated results to Excel or CSV
- Excel export includes frozen header and sensible column widths
- Responsive, modern PySide6 interface
- No Streamlit server required

## Conversion basis

- 1 Kanal = 20 Marla
- 1 Killa = 8 Kanal = 160 Marla
- 1 Marla = 9 Sarshai

## Run

Install dependencies:

```powershell
pip install -r requirements.txt
```

Run:

```powershell
python land_share_calculator.py
```

## Example

Total land: 10 Kanal

Owners:
- A: 1/2
- B: 1/4
- C: 1/4

The application calculates each owner's proportional area and reports it in both decimal Marla and Killa-Kanal-Marla-Sarshai form.

## Important

This is a calculation utility, not a legal determination of title, mutation, inheritance, or revenue-record entitlement. Always verify calculations against the applicable revenue record and local rules.
